package com.ferpat.pruebasoli;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
public class UsuarioActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrousuario);
    }

    public void irMenuP(View v){
        Intent men=new Intent(this,MenuActivity.class);
        startActivity(men);
    }

}
