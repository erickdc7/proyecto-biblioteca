package com.ferpat.pruebasoli;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
    }
    public void irLogin(View v){
        Intent men=new Intent(this,LoginActivity.class);
        startActivity(men);

    }
    public void iraRegistro(View v){
        Intent reg=new Intent(this,UsuarioActivity.class);
        startActivity(reg);

    }
}